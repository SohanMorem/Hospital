import React, { useState } from "react";

const Login = () => {
  const [login, setLogin] = useState("Sign Up");
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    cpassword: "",
  });
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    let formErrors = {};
    if (!formData.username.trim()) {
      formErrors.username = "Username is required";
    }
    if (!formData.email.trim()) {
      formErrors.email = "Email is required";
    } else if (!/^[a-zA-Z0-9._%+-]{5}@gmail\.com$/.test(formData.email)) {
      formErrors.email = "Enter a valid Gmail address.";
    }
    if (!formData.password.trim()) {
      formErrors.password = "Password is required";
    }else if (formData.password.length < 8) {
      formErrors.password = "Password must be at least 8 characters long.";
    }
    if (!formData.cpassword.trim()) {
      formErrors.cpassword = "Confirm Password is required";
    }else if (login === "Sign Up" && formData.password !== formData.cpassword) {
      formErrors.cpassword = "Passwords do not match.";
    }

    setErrors(formErrors);
    return Object.keys(formErrors).length === 0; // Returns true if no errors
  };

  const onSubmitHandle = (e) => {
    e.preventDefault();
    if (validateForm()) {
      alert("Form submitted successfully!");
      setFormData({
        username: "",
        email: "",
        password: "",
        cpassword: "",
      });
      setErrors({});
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div>
      <div className="flex items-center justify-center min-h-screen bg-gray-100 pt-12">
        <div className="w-full max-w-md p-6 mb-24 bg-white rounded-lg shadow-md">
          <h1 className="text-2xl font-bold text-center text-gray-800 mb-6">
            {login} Page
          </h1>
          <form className="space-y-4" onSubmit={onSubmitHandle}>
            {login === "Sign Up" && (
              <div>
                <label
                  htmlFor="username"
                  className="block text-sm font-medium text-gray-700"
                >
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                    errors.username
                      ? "border-red-500 focus:ring-red-500"
                      : "focus:ring-blue-500"
                  }`}
                  placeholder="Enter your username"
                  onChange={handleInputChange}
                  value={formData.username}
                />
                {errors.username && (
                <p className="text-red-500 text-sm mt-1">{errors.username}</p>
              )}
              </div>
            )}

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-700"
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                  errors.email
                    ? "border-red-500 focus:ring-red-500"
                    : "focus:ring-blue-500"
                }`}
                placeholder="Enter your email"
                onChange={handleInputChange}
                value={formData.email}
              />
              {errors.email && (
                <p className="text-red-500 text-sm mt-1">{errors.email}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                Password
              </label>
              <input
                type="text"
                id="password"
                name="password"
                className="block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="Enter your password"
                onChange={handleInputChange}
                value={formData.password}
              />
              {errors.password && (
                <p className="text-red-500 text-sm mt-1">{errors.password}</p>
              )}
            </div>

            {login === "Sign Up" && (
              <div>
                <label
                  htmlFor="cpassword"
                  className="block text-sm font-medium text-gray-700"
                >
                  Confirm Password
                </label>
                <input
                  type="text"
                  id="cpassword"
                  name="cpassword"
                  className="block w-full px-3 py-2 mt-1 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Confirm your password"
                  onChange={handleInputChange}
                  value={formData.cpassword}
                />
                {errors.cpassword && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.cpassword}
                  </p>
                )}
              </div>
            )}

            <button
              type="submit"
              className="w-full px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              {login === "Sign Up" ? "Continue" : "Login"}
            </button>
          </form>

          {login === "Sign Up" ? (
            <p className="mt-4 text-sm text-center text-gray-600">
              Already have an account?{" "}
              <button
                onClick={() => setLogin("Login")}
                className="text-blue-500 hover:underline"
              >
                Login Here
              </button>
            </p>
          ) : (
            <p className="mt-4 text-sm text-center text-gray-600">
              Don't have an account?{" "}
              <button
                onClick={() => setLogin("Sign Up")}
                className="text-blue-500 hover:underline"
              >
                Sign up here
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
