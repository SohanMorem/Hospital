import React, { useState } from 'react';
import { assets } from '../assets/assets';

const Contact = () => {
  // State to manage form data and errors
  
  const [formData,setFormData]=useState({
    username:'',
    email:'',
    phone:'',
    message:''
  })

  const [errors,setErrors]=useState({})

  const handleChange=(e)=>{
    const {name,value}=e.target;
    setFormData({...formData,[name]:value})
  }

  const validateForm=()=>{
      let formErrors={};

      if(!formData.username.trim()){
        formErrors.username="User Name is required";
      }
      if(!formData.email.trim()){
        formErrors.email="email is required";
      }else if (!/^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(formData.email)) {
        formErrors.email = 'Enter a valid Gmail address.';
      }
      
      if(!formData.phone.trim()){
        formErrors.phone="phone number is required";
      }else if(!/^\d{10}/.test(formData.phone)){
        formErrors.phone="Enter a valid phone number.";
      }
      if(!formData.message.trim()){
        formErrors.message="Message is required";
      }

      setErrors(formErrors)
      return Object.keys(formErrors).length === 0;  // Returns true if no errors
  }

  const handleSubmit=(e)=>{
    e.preventDefault()
    if(validateForm()){
      alert("form")
      setFormData({
        username:'',
        email:'',
        phone:'',
        message:''
      })  
      setErrors({})
    }
  }


  return (
    <div className="flex flex-wrap justify-center items-center h-screen bg-gray-100 p-4">
      {/* Left Side: Image */}
      <div className="w-full md:w-1/2 flex justify-center items-center p-4">
        <img
          src={assets.contact_image}
          alt="Hospital Contact"
          className="rounded-lg shadow-lg max-w-full h-auto"
        />
      </div>

      {/* Right Side: Form */}
      <div className="w-full md:w-1/2 bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">Contact Us</h2>
        <form onSubmit={handleSubmit}>
          {/* User Name */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
              User Name
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              placeholder="Enter your name"
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                errors.username ? 'border-red-500 focus:ring-red-500' : 'focus:ring-blue-500'
              }`}
            />
            {errors.username && <p className="text-red-500 text-sm mt-1">{errors.username}</p>}
          </div>

          {/* Email Address */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
              Email Address
            </label>
            <input
              type="text"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email address"
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                errors.email ? 'border-red-500 focus:ring-red-500' : 'focus:ring-blue-500'
              }`}
            />
            {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
          </div>

          {/* Phone Number */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="phone">
              Phone Number
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Enter your phone number"
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                errors.phone ? 'border-red-500 focus:ring-red-500' : 'focus:ring-blue-500'
              }`}
            />
            {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
          </div>

          {/* Message */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="message">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="4"
              placeholder="Enter your message"
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 ${
                errors.message ? 'border-red-500 focus:ring-red-500' : 'focus:ring-blue-500'
              }`}
            ></textarea>
            {errors.message && <p className="text-red-500 text-sm mt-1">{errors.message}</p>}
          </div>

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Contact;
